# Grid3D 独立重构说明

## 模块定位

`GameType.Grid3D = 1006` 是独立于 `GameType.Grid = 1002` 的 3D 玩法模块，代码模块名为 `gameGrid3D`。

当前目标是搭建 roguelike + 塔防 + 割草方向的战斗框架，不在本阶段实现完整业务规则。现有回合、生成、建造、方块放置逻辑只作为 3D 运行时占位流程保留。

战斗玩法设计草案见 `grid3d-combat-design.md`，当前方向为“构建消除 + 地块养成 + 自动战斗 + 核心据点防守”。

## 目录边界

客户端代码：

- `assets/script/game/gameGrid3D/`：Grid3D Controller、View、场景层、Entity、Component、Vo、状态机、事件和工具。
- `assets/script/cache/GameGrid3DCache.ts`：Grid3D 局内运行时缓存。
- `assets/game/ui/gameGrid3D/`：Grid3D UI Prefab 资源路径，暂不改动。
- `assets/game/scene/gameGrid3D/`：Grid3D 场景和 3D 资源路径，暂不改动。

与 2D Grid 的边界：

- `assets/script/game/gameGrid/` 只服务 `GameType.Grid = 1002`。
- `assets/script/cache/GameGridCache.ts` 只保留 2D Grid 排行榜、皮肤、存档、道具和方块预览等职责。
- Grid3D 不接入 1002 的排行榜、皮肤、存档、广告道具链路。
- Grid3D 代码不得引用 `CacheManager.gameGrid` 或 2D `gameGrid` 模块；如需同形数据类型，应在 `gameGrid3D` 内定义独立类型。

## Controller 与 Cache

`ControllerManager` 同时初始化：

- `GameGridController`：只响应 `GameType.Grid`。
- `GameGrid3DController`：只响应 `GameType.Grid3D`。

`CacheManager.gameGrid3D` 暴露 `GameGrid3DCache`，当前职责包括：

- 局内初始化与清理：`initGameData()`、`clearAll()`。
- 地图数据初始化：Controller 收到 `OnGameResAllReady` 后先调用 `initGameData()`，生成 `mapGridList` 等数据，再创建场景视图。
- 回合占位状态：`roundType`、`round`、`switchRound()`、`isBattle()`、`sceneReady`。
- Entity 注册与删除：`addEntity()`、`delEntity()`。
- 目标查询：`findTarget()`、`findTargetByList()`、`getSelectedEntity()`。
- 方块预览占位数据：`getGridDataList()`、`getRandomType()`。

## Entity-Component-EntityVo 设计

Grid3D 保持“每个单位都是独立作战个体”的框架：

- `BaseEntity` 是运行时逻辑实体和自定义组件载体，不继承 Cocos `Node`，不再要求脚本挂载到完整实体 Prefab。
- Entity 可持有逻辑父层引用，供显示组件确定挂载位置；Entity 本身不创建、不持有具体显示节点。
- `EntityComponent` 是自定义组件对象，不继承 Cocos `Component`；战斗、移动、显示同步都通过该组件体系运行。
- Entity 的行为由挂载的 Component 决定，例如 `BattleComponent`、`RVOMoveComponent`、`ActorComponent`、`HUDComponent`。
- `EntityVo` 是实体数据与状态事件源，继承 `BaseVo`，通过属性事件通知 Component；状态、位置、选中、预览、朝向等可表现数据都应先写入 Vo。
- 显示对象由 `EntityDisplayComponent` 或后续专用显示层按需创建、持有和回收，可按 `modelUrl` 等资源字段异步加载部件 Prefab。
- Entity 初始化时绑定 Vo，调用 `vo.setEntity(this)`，再挂载组件并同步初始状态。
- 组件绑定 Entity 后必须调用 `updateVo()`；显示组件在显示对象迟到时必须从 Vo 全量同步当前快照，不能依赖错过的历史表现事件。
- 地图不可见或显示对象尚未创建时，战斗逻辑仍应继续运行；核心战斗结算、寻路、攻击范围不应依赖 Cocos 显示节点或 Collider。

`EntityVo` 当前最小通用 API：

- 基础属性：`id`、`type`、`name`、`level`。
- 位置与状态：`pos`、`worldPos`、`state`、`defaultState`、`setState()`、`updatePos()`。
- 战斗属性：`hp`、`maxHp`、`attack`、`battleVo`、`skills`、`isDead()`。
- 展示与资源：`getShowName()`、`modelUrl`、`getNextSkillId()`、`visible`、`isSelected`、`forward`、`setPreview()`。

后续新增单位时，应优先新增 Vo 子类和 Component 组合，不应把具体业务分支堆回 Controller 或 Cache。

## 地图格子层与实体层职责

- `GameMapGridLayer` 负责地图交互格子：从 `CacheManager.gameGrid3D.mapGridList` 读取格子数据，创建并管理对应 `GameGridMapItem` 逻辑对象。
- `GameMapGridLayer` 负责 Ready 阶段的预览方块、拖动检测、落点检测、行列消除检查，并通过 Vo 更新格子状态。
- `GameEntityLayer` 不再创建地图交互格子，不再执行预览和拖放检测；该层只作为动态战斗实体的生命周期管理入口。
- `GameGridMap` 对外仍暴露 `createPreviewGrid()` 和 `onGridDrop()`，但内部委托给 `LayerType.Preview` 对应的 `GameMapGridLayer`。

## 事件边界

Grid3D 内部事件使用 `MessageCenter/GEvent`，事件定义位于：

- `assets/script/game/gameGrid3D/event/GameGrid3DEvent.ts`

当前 3D 专用事件统一使用 `OnGameGrid3D...` 命名，例如：

- `OnGameGrid3DSceneReady`
- `OnGameGrid3DRoundUpdate`
- `OnGameGrid3DEntityInit`
- `OnGameGrid3DEntityDelete`
- `OnGameGrid3DSceneGridCreate`
- `OnGameGrid3DSceneGridDrop`

只在玩法入口、退出和主界面切换等全局流程继续使用 `EventManager/EventEnum`。

## 当前占位逻辑

- Ready 阶段由 `GameMapGridLayer` 允许拖拽预览方块并放置到 3D 棋盘。
- Battle 阶段按计时生成敌人，并由组件系统驱动目标查询、移动、攻击和表现。
- 建造英雄目前从选中格子创建 `EntityType.Hero`，完整塔防建造规则未实现。
- 清行、得分、波次切换等逻辑仍是框架占位，不代表最终玩法设计。

## 后续开发要求

- 继续保持 `gameGrid3D` 与 `gameGrid` 完全解耦。
- 移动 Cocos 脚本时必须同步移动 `.ts.meta`，优先保留脚本 UUID，避免 Prefab 脚本绑定丢失。
- 新增 3D 事件必须使用 `OnGameGrid3D...` 命名，不复用 2D Grid 事件。
- 新增局内运行时状态优先放入 `GameGrid3DCache`，但不要把具体战斗行为塞进 Cache。
- 新增单位行为优先通过 Component 组合表达，Entity 只作为 Node 载体和状态表现入口。
- 修改 Grid3D 架构、事件、缓存、资源路径或运行流程时，必须同步更新本文档和相关 `MiniGame/docs/` 文档。
